This is the readme for the models associated with the paper:

Popovic M, Djurisic M, Zecevic D (2005) Determinants of low EPSP
attenuation in primary dendrites of mitral cells: modeling study. Ann
N Y Acad Sci 1048:344-8

This NEURON code as used by the paper authors and was supplied by
Marko Popovic.

Please see the folders:

model_bf_HPP
model_bf_real_EPSP

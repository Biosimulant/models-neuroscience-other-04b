
#ifndef DTNET_H
#define DTNET_H


#include <iostream>
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <string>
#include <list>
#include <boost/program_options.hpp>
#include "vt100.h"
#include "dtlang.h"
#include "lib/SReadline/SReadline.h"

extern bool dtlang::verbose;

#endif

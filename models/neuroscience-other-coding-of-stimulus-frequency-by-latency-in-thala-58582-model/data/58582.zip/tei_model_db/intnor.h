#define Mar 1000

typedef struct fl_st{
  FILE *dat, *out, *res;
} fl_st;

This archive contains model code for the paper

Overstreet CK, Klein JD, Helms Tillery SI (2013) Computational
modeling of direct neuronal recruitment during intracortical
microstimulation in somatosensory cortex J Neural Eng. 10(6):066016

Please look in the Slice_Simulation folder (for matlab code) or the
NEURON_code folder.  More information is available in the readme files
in those directories.

This code was contributed by Cynthia Overstreet.

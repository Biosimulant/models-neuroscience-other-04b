This model is associated with the paper:

Kuznetsov AS, Kopell NJ, Wilson CJ.
Transient high-frequency firing in a coupled-oscillator model of the
mesencephalic dopaminergic neuron.
J Neurophysiol. 2006 Feb;95(2):932-47. Epub 2005 Oct 5.

and was supplied by AS Kuznetsov.

Use:

Expand the archive and cd into the newly created directory and run:

xppaut KuzKopWil2006.ode

then click on Initialcond -> Go

The soma trace from Fig 8A of the paper is reproduced.

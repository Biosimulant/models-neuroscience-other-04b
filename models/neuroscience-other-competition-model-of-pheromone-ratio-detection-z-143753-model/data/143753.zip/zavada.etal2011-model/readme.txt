This is the readme for the model associated with the paper

Zavada A, Buckley CL, Martinez D, Rospars JP, Nowotny T (2011)
Competition-based model of pheromone component ratio detection in the
moth. PLoS One 6:e16308

This is the neuroConstruct code that the authors used.

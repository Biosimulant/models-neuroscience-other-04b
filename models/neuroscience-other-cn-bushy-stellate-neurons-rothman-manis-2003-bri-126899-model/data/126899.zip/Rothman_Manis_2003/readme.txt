This is the readme for a "brian" version of the model from the paper:

Rothman JS, Manis PB (2003) The roles potassium currents play in
regulating the electrical activity of ventral cochlear nucleus
neurons. J Neurophysiol 89:3097-113

Brian is python based and installation instructions can be found at:

http://www.briansimulator.org/docs/installation.html

This model was contributed by Brette Romain
romain.brette at ens.fr

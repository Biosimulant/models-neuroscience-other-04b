DG-BasketCellx.hoc contains the details of morphology of cell x
- the procedure topol() defines the 3D points of the neuron and the connections between the compartments;
- the procedure secdef() defines the number of nseg for each compartment; the number is defined in the file Nseg_BCx.txt, that needs to be called by secdef()

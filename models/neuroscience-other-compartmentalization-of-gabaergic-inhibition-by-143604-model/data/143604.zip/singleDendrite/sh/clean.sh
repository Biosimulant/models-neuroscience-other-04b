rm -r -f multiconditions/*/*txt
rm -r -f nrnmech.dll i686 x86_64 mod/*.c mod/*.o fig?/*txt param3/*/*/*txt mod/nrnmech.dll *~
rm -r -f sealed_end/*/*.txt
rm `find ./impedance -name \*txt -print`
rm `find ./NaKgs -type f -print`
rm `find ./fig2 -name \*txt -print`
rm `find ./results -type f -print`
rm `find ./figSuppl -type f -print`

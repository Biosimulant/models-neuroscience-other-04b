echo 'Type a command like
grep -E "^99  " */*cai*
to see the baselines when ctrl-v ctrl-i makes the tab following the 99'

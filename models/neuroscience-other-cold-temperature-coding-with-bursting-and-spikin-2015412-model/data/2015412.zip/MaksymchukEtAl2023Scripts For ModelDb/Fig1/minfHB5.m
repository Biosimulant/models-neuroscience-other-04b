function ff=minfHB5(A,B,V)
ff=1../(1.+exp(-(V+B)./A));



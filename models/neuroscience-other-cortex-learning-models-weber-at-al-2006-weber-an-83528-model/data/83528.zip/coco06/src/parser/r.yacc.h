#ifndef _r_yacc_H
#define _r_yacc_H

#include <stdio.h>

PARAMS     *alloc_g (FILE *fp);
AREA       *alloc_a ();
SIMULATION *alloc_si ();

#endif

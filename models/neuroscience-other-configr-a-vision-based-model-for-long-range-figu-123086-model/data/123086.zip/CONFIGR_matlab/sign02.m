function A=sign02(B);
A=sign(B);
Cindex=find(A==-1);
A(Cindex)=0;



    



    
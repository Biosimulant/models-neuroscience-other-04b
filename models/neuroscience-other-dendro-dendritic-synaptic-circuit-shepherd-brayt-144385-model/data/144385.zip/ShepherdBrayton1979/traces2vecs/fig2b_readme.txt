I rotated the Fig2B.tiff -.25 degrees in idraw before tracing with polylines.

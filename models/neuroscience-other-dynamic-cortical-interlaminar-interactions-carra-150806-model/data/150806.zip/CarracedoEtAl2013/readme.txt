This is the model associated with the paper:

Carracedo L, Kjeldsen H, Cunnington L, Jenkins A, Schofield I,
Cunningham M, Davies C, Traub R (2013) A neocortical delta rhythm
facilitates reciprocal interlaminar interactions via nested theta
rhythms. J Neurosci 33:10750-61

This code was contributed by Roger Traub.
